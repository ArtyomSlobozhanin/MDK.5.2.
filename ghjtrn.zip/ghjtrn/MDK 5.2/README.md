# Spring-Boot-CRUD-Tutorial
Spring Boot CRUD Tutorial with IntelliJ IDEA, MySQL, JPA, Hibernate, Thymeleaf and Bootstrap


Technologies: Spring Boot Web, Spring Data JPA & Hibernate, MySQL Database, Thymeleaf, HTML5 & Bootstrap, JUnit 5 & AssertJ, Spring Data JPA Test.

Software programs: Java Development Kit (OpenJDK), IntelliJ IDEA Ultimate, MySQL Community Server, MySQL Workbench
